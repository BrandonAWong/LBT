const BASE_PATH = import.meta.env.VITE_BASE_PATH;

export default BASE_PATH;