export default function Unauthorized() {
    return (
        <p>You are unauthorized to access this content</p>
    )
}